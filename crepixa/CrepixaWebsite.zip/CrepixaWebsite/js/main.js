$(function () {
    "use strict";
    //ScrollTo The Top
    $(window).scroll(function () {
        var height = $(window).scrollTop();
        if (height > 100) {
            $('.scrollTop').fadeIn();
        } else {
            $('.scrollTop').fadeOut();
        }
    });
    $('.scrollTop').click(function () {
        $('html, body').animate({
            scrollTop: 0
        }, 1000);
    });
    // Team slider
    $(document).ready(function () {
        $('.owl-carousel').owlCarousel({
            rtl: true,
            loop: true,
            margin: 30,
            autoplay: true,
            autoplayTimeout: 2000,
            autoplayHoverPause: true,
            navText: ['<i class="fas fa-chevron-right"></i>', '<i class="fas fa-chevron-left"></i>'],
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: 4
                }
            }
        });
    });

    // PickImg
    $("select").imagepicker();

    //Upload Img
    const readURL = (input) => {
        if (input.files && input.files[0]) {
            const reader = new FileReader()
            reader.onload = (e) => {
                $('#preview').attr('src', e.target.result)
            }
            reader.readAsDataURL(input.files[0])
        }
    }
    $('.choose').on('change', function () {
        readURL(this)
        let i
        if ($(this).val().lastIndexOf('\\')) {
            i = $(this).val().lastIndexOf('\\') + 1
        } else {
            i = $(this).val().lastIndexOf('/') + 1
        }
        const fileName = $(this).val().slice(i)
        $('.label').text(fileName)
    })

});


//testimonials Slider
var galleryTop = new Swiper('.gallery-top', {
    spaceBetween: 10,
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    loop: true,
    loopedSlides: 4
});
var galleryThumbs = new Swiper('.gallery-thumbs', {
    spaceBetween: 10,
    centeredSlides: true,
    slidesPerView: 'auto',
    touchRatio: 0.2,
    slideToClickedSlide: true,
    loop: true,
    loopedSlides: 4
});
galleryTop.controller.control = galleryThumbs;
galleryThumbs.controller.control = galleryTop;

//Start The Equal sections Height

(function () {
    equalHeight(false);
})();

window.onresize = function () {
    equalHeight(true);
}

function equalHeight(resize) {
    var elements = document.getElementsByClassName("equalHeight"),
        allHeights = [],
        i = 0;
    if (resize === true) {
        for (i = 0; i < elements.length; i++) {
            elements[i].style.height = 'auto';
        }
    }
    for (i = 0; i < elements.length; i++) {
        var elementHeight = elements[i].clientHeight;
        allHeights.push(elementHeight);
    }
    for (i = 0; i < elements.length; i++) {
        elements[i].style.height = Math.max.apply(Math, allHeights) + 'px';
        if (resize === false) {
            elements[i].className = elements[i].className + " show";
        }
    }
}

//End The Equal sections Height

$('.main-slider').carousel({
    interval: 2000
})